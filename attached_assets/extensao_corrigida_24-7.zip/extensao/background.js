// OnlineOffice IPTV Automator - Background Script (24/7 Version)
// Versão corrigida para funcionar sempre em background

// ===========================================================================
// SISTEMA DE LOGS 
// ===========================================================================
class ExtensionLogger {
  constructor() {
    this.MAX_LOGS = 1000;
    this.STORAGE_KEY = 'extension_logs';
    this.LOG_LEVELS = {
      DEBUG: 'DEBUG',
      INFO: 'INFO', 
      WARN: 'WARN',
      ERROR: 'ERROR'
    };
    this.LOG_COLORS = {
      DEBUG: '#6c757d',
      INFO: '#0d6efd',
      WARN: '#ffc107',
      ERROR: '#dc3545'
    };
  }

  // Adiciona log ao chrome.storage.local
  async addLog(level, message, context = {}) {
    const logs = await this.getLogs();
    const logEntry = {
      timestamp: new Date().toISOString(),
      level: level,
      message: message,
      context: context
    };
    
    logs.push(logEntry);
    
    // Manter apenas os últimos MAX_LOGS
    if (logs.length > this.MAX_LOGS) {
      logs.splice(0, logs.length - this.MAX_LOGS);
    }
    
    try {
      await chrome.storage.local.set({ [this.STORAGE_KEY]: logs });
    } catch (e) {
      // Se falhar ao salvar, limpar logs antigos
      await this.clearOldLogs();
      await chrome.storage.local.set({ [this.STORAGE_KEY]: logs.slice(-500) });
    }
    
    // Também enviar para o console com estilo
    const color = this.LOG_COLORS[level] || '#000';
    console.log(
      `%c[${level}] ${new Date().toLocaleTimeString()} - ${message}`,
      `color: ${color}; font-weight: ${level === 'ERROR' ? 'bold' : 'normal'}`
    );
    if (Object.keys(context).length > 0) {
      console.log('Context:', context);
    }
  }

  // Recupera todos os logs
  async getLogs() {
    try {
      const result = await chrome.storage.local.get(this.STORAGE_KEY);
      return result[this.STORAGE_KEY] || [];
    } catch (e) {
      return [];
    }
  }

  // Filtra logs por nível
  async getLogsByLevel(level) {
    const logs = await this.getLogs();
    return logs.filter(log => log.level === level);
  }

  // Busca logs por texto
  async searchLogs(searchText) {
    const lowerSearch = searchText.toLowerCase();
    const logs = await this.getLogs();
    return logs.filter(log => 
      log.message.toLowerCase().includes(lowerSearch) ||
      JSON.stringify(log.context).toLowerCase().includes(lowerSearch)
    );
  }

  // Limpa todos os logs
  async clearLogs() {
    await chrome.storage.local.remove(this.STORAGE_KEY);
    await this.info('Logs limpos pelo usuário');
  }

  // Limpa logs antigos (mantém apenas os últimos 500)
  async clearOldLogs() {
    const logs = await this.getLogs();
    if (logs.length > 500) {
      const recentLogs = logs.slice(-500);
      await chrome.storage.local.set({ [this.STORAGE_KEY]: recentLogs });
    }
  }

  // Métodos de conveniência para cada nível
  async debug(message, context = {}) {
    await this.addLog(this.LOG_LEVELS.DEBUG, message, context);
  }

  async info(message, context = {}) {
    await this.addLog(this.LOG_LEVELS.INFO, message, context);
  }

  async warn(message, context = {}) {
    await this.addLog(this.LOG_LEVELS.WARN, message, context);
  }

  async error(message, context = {}) {
    await this.addLog(this.LOG_LEVELS.ERROR, message, context);
  }

  // Formata logs para exibição
  async formatLogs(logs = null) {
    const logsToFormat = logs || await this.getLogs();
    return logsToFormat.map(log => {
      const date = new Date(log.timestamp);
      const timeStr = date.toLocaleTimeString('pt-BR');
      const dateStr = date.toLocaleDateString('pt-BR');
      const contextStr = Object.keys(log.context).length > 0 
        ? ` | ${JSON.stringify(log.context)}` 
        : '';
      return `[${log.level}] ${dateStr} ${timeStr} - ${log.message}${contextStr}`;
    }).join('\n');
  }

  // Exporta logs como texto
  async exportAsText() {
    const logs = await this.getLogs();
    const header = `=== OnlineOffice Extension Logs ===\n`;
    const exportDate = `Exportado em: ${new Date().toLocaleString('pt-BR')}\n`;
    const totalLogs = `Total de logs: ${logs.length}\n`;
    const separator = '=' .repeat(50) + '\n\n';
    
    const formatted = await this.formatLogs(logs);
    return header + exportDate + totalLogs + separator + formatted;
  }
}

// Instância global do logger
const logger = new ExtensionLogger();

// ===========================================================================
// CONFIGURAÇÃO
// ===========================================================================
// Função para determinar a URL do servidor dinamicamente
async function getApiBase() {
  // Primeiro, verifica se há uma configuração salva no storage
  const stored = await chrome.storage.local.get('apiBase');
  if (stored.apiBase) {
    await logger.info(`📍 Usando API configurada: ${stored.apiBase}`);
    return stored.apiBase;
  }
  
  // Lista de servidores possíveis em ordem de prioridade
  const servers = [
    'http://localhost:5000',           // Desenvolvimento local
    'http://127.0.0.1:5000',          // Desenvolvimento local alternativo
    'https://tv-on.site'               // Produção
  ];
  
  // Tenta cada servidor para ver qual está disponível
  for (const server of servers) {
    try {
      await logger.debug(`🔍 Testando servidor: ${server}`);
      const response = await fetch(`${server}/api`, {
        method: 'HEAD',
        mode: 'cors'
      }).catch(() => null);
      
      if (response && response.ok) {
        await logger.info(`✅ Servidor disponível: ${server}`);
        // Salva o servidor funcional no storage
        await chrome.storage.local.set({ apiBase: server });
        return server;
      }
    } catch (e) {
      await logger.debug(`❌ Servidor não disponível: ${server}`);
    }
  }
  
  // Se nenhum servidor responder, usa o padrão de produção
  await logger.warn('⚠️ Nenhum servidor respondeu, usando produção como fallback');
  return 'https://tv-on.site';
}

// Variável global para armazenar a URL do API
let API_BASE = null;
const OFFICE_URL = 'https://onlineoffice.zip/'; // URL base do OnlineOffice
let officeTabId = null; // Armazena o ID da aba do OnlineOffice
let keepAliveTabId = null; // ID da aba mantida sempre aberta

// ===========================================================================
// ESTADO GLOBAL (mínimo, apenas para cache)
// ===========================================================================
let isProcessingTask = false;
let lastStatus = {
  isEnabled: false,
  badge: '',
  lastCheck: 0
};
let heartbeatTimer = null;

// ===========================================================================
// FUNÇÃO CRÍTICA: MANTER ABA SEMPRE ABERTA (24/7)
// ===========================================================================
async function maintainOfficeTab() {
  try {
    // Busca todas as abas do OnlineOffice
    const tabs = await chrome.tabs.query({
      url: ['*://onlineoffice.zip/*', '*://*.onlineoffice.zip/*']
    });
    
    if (tabs.length === 0) {
      // SEMPRE abre uma aba se não houver nenhuma
      await logger.info('🚀 [24/7] Abrindo aba OnlineOffice (obrigatório para funcionamento 24/7)...');
      
      const newTab = await chrome.tabs.create({
        url: OFFICE_URL,
        active: false, // Abre em background
        pinned: true  // Fixa a aba para não fechar acidentalmente
      });
      
      keepAliveTabId = newTab.id;
      officeTabId = newTab.id;
      
      await logger.info(`✅ [24/7] Aba criada e fixada (ID: ${keepAliveTabId})`);
      
      // Aguarda carregamento
      await new Promise(resolve => setTimeout(resolve, 5000));
    } else {
      // Já tem aba, apenas atualiza o ID
      keepAliveTabId = tabs[0].id;
      officeTabId = tabs[0].id;
      
      // Fixa a aba se não estiver fixada
      if (!tabs[0].pinned) {
        await chrome.tabs.update(tabs[0].id, { pinned: true });
        await logger.debug(`📌 [24/7] Aba fixada (ID: ${keepAliveTabId})`);
      }
    }
  } catch (error) {
    await logger.error('[24/7] Erro ao manter aba:', { error: error.message });
  }
}

// ===========================================================================
// SISTEMA DE HEARTBEAT MELHORADO (FUNCIONA SEM ABA)
// ===========================================================================
async function sendHeartbeat() {
  try {
    let isLoggedIn = false;
    let currentUrl = '';
    
    // Tenta buscar info da aba se existir
    const tabs = await chrome.tabs.query({
      url: ['*://onlineoffice.zip/*', '*://*.onlineoffice.zip/*']
    });
    
    if (tabs.length > 0) {
      const activeTab = tabs[0];
      currentUrl = activeTab.url || '';
      isLoggedIn = currentUrl.includes('onlineoffice.zip') && !currentUrl.includes('#/login');
    }
    
    await logger.debug(`💓 [24/7] Heartbeat - URL: ${currentUrl || 'sem aba'}, Logado: ${isLoggedIn}`);
    
    // Envia heartbeat para o backend SEMPRE
    if (API_BASE) {
      const response = await fetch(`${API_BASE}/api/extension/heartbeat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Extension-Key': 'tvon-extension-2024'
        },
        body: JSON.stringify({
          currentUrl: currentUrl || 'background-only',
          isLoggedIn: isLoggedIn,
          userAgent: navigator.userAgent,
          extensionVersion: chrome.runtime.getManifest().version,
          timestamp: new Date().toISOString(),
          metadata: {
            tabId: keepAliveTabId,
            hasTab: tabs.length > 0,
            mode: '24/7'
          }
        })
      });
      
      if (!response.ok) {
        await logger.warn(`⚠️ [24/7] Heartbeat falhou: ${response.status}`);
      } else {
        await logger.debug('✅ [24/7] Heartbeat enviado com sucesso');
      }
    }
    
  } catch (error) {
    await logger.debug('[24/7] Erro no heartbeat:', { error: error.message });
  }
}

// ===========================================================================
// FUNÇÃO DE ENVIO DE MENSAGEM COM RETRY
// ===========================================================================
async function sendMessageToTab(tabId, message, retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      // Verifica se a aba ainda existe
      const tab = await chrome.tabs.get(tabId);
      if (!tab) throw new Error('Tab not found');
      
      // Tenta ativar a aba para evitar cache
      await chrome.tabs.update(tabId, { active: true });
      await new Promise(resolve => setTimeout(resolve, 200));
      
      // Envia mensagem
      const response = await chrome.tabs.sendMessage(tabId, message);
      return response;
    } catch (error) {
      await logger.error(`Tentativa ${i + 1}/${retries} falhou:`, { error: error.message });
      
      if (i < retries - 1) {
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Tenta reinjetar o content script se necessário
        try {
          await chrome.scripting.executeScript({
            target: { tabId: tabId },
            files: ['content.js']
          });
          await logger.info('✅ Content script reinjetado com sucesso');
        } catch (e) {
          await logger.warn('Não foi possível reinjetar content script:', { error: e.message });
        }
      } else {
        throw error;
      }
    }
  }
}

// ===========================================================================
// INICIALIZAÇÃO 24/7
// ===========================================================================
(async () => {
  await logger.info('🚀 [24/7] Background script iniciado - Versão SEMPRE ATIVA');
  
  // Inicializa API_BASE dinamicamente
  API_BASE = await getApiBase();
  await logger.info(`🔗 [24/7] Servidor API configurado: ${API_BASE}`);
  
  // CRÍTICO: Garante que sempre há uma aba aberta
  await maintainOfficeTab();
  
  // Inicia heartbeat para manter conexão viva
  setupHeartbeat();
  
  // Configura alarmes para funcionamento 24/7
  await setupAlarms();
})();

// ===========================================================================
// HEARTBEAT PARA MANTER CONEXÃO VIVA
// ===========================================================================
function setupHeartbeat() {
  // Envia heartbeat imediatamente
  sendHeartbeat();
  
  // Configura intervalo para enviar heartbeat a cada 30 segundos
  if (heartbeatTimer) clearInterval(heartbeatTimer);
  heartbeatTimer = setInterval(async () => {
    await sendHeartbeat();
  }, 30000); // A cada 30 segundos
  
  logger.info('💓 [24/7] Sistema de heartbeat configurado (a cada 30s)');
}

// ===========================================================================
// ALARMES PARA FUNCIONAMENTO 24/7
// ===========================================================================
async function setupAlarms() {
  // Remove alarmes anteriores
  await chrome.alarms.clearAll();
  
  // Alarme principal para checagem de tarefas (a cada 20 segundos)
  chrome.alarms.create('pollBackend', {
    periodInMinutes: 0.33, // 20 segundos
    delayInMinutes: 0 // Começa imediatamente
  });
  
  // Alarme para manter aba aberta (a cada 2 minutos)
  chrome.alarms.create('maintainTab', {
    periodInMinutes: 2, // A cada 2 minutos
    delayInMinutes: 0.1 // Começa em 6 segundos
  });
  
  // Alarme de heartbeat adicional (a cada 1 minuto)
  chrome.alarms.create('heartbeat', {
    periodInMinutes: 1,
    delayInMinutes: 0.05 // Começa em 3 segundos
  });
  
  await logger.info('⏰ [24/7] Alarmes configurados para operação contínua');
}

// ===========================================================================
// LISTENER PARA ALARMES 24/7
// ===========================================================================
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'pollBackend') {
    await logger.debug('⏰ [24/7] Alarme: Checando tarefas...');
    await checkForTasks();
  } else if (alarm.name === 'maintainTab') {
    await logger.debug('⏰ [24/7] Alarme: Verificando aba...');
    await maintainOfficeTab();
  } else if (alarm.name === 'heartbeat') {
    await logger.debug('⏰ [24/7] Alarme: Enviando heartbeat...');
    await sendHeartbeat();
  }
});

// ===========================================================================
// EVENTOS DE INICIALIZAÇÃO 24/7
// ===========================================================================
// Quando o Chrome inicia
chrome.runtime.onStartup.addListener(async () => {
  await logger.info('📦 [24/7] Chrome iniciado - Ativando modo 24/7...');
  await maintainOfficeTab(); // SEMPRE abre aba
  await setupAlarms();
  await setupHeartbeat();
  await checkForTasks();
});

// Quando instalado/atualizado
chrome.runtime.onInstalled.addListener(async (details) => {
  await logger.info(`🔧 [24/7] Extensão ${details.reason} - Ativando modo 24/7...`);
  await maintainOfficeTab(); // SEMPRE abre aba
  await setupAlarms();
  await setupHeartbeat();
  await checkForTasks();
});

// Quando uma aba do OnlineOffice é fechada
chrome.tabs.onRemoved.addListener(async (tabId) => {
  if (tabId === keepAliveTabId) {
    await logger.warn('⚠️ [24/7] Aba OnlineOffice foi fechada! Reabrindo...');
    keepAliveTabId = null;
    await maintainOfficeTab(); // Reabre imediatamente
  }
});

// ===========================================================================
// CHECAGEM DE TAREFAS (FUNCIONA 24/7)
// ===========================================================================
async function checkForTasks() {
  // Se já está processando, pula esta checagem
  if (isProcessingTask) {
    await logger.debug('⏳ Já processando tarefa, pulando checagem...');
    return;
  }
  
  // Evita requisições muito frequentes
  const now = Date.now();
  if (now - lastStatus.lastCheck < 5000) {
    return; // Silencioso, sem log para não poluir
  }
  lastStatus.lastCheck = now;
  
  // Garante que API_BASE está definido
  if (!API_BASE) {
    API_BASE = await getApiBase();
  }
  
  try {
    // Garante que sempre há uma aba
    await maintainOfficeTab();
    
    const fullUrl = `${API_BASE}/api/office/automation/next-task`;
    
    // Consulta próxima tarefa no backend
    const response = await fetch(fullUrl, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'X-Extension-Key': 'chrome-extension-secret-2024'
      }
    }).catch(async err => {
      await logger.error('❌ Erro na requisição:', { error: err.message });
      return null;
    });
    
    if (!response) {
      await updateBadge(false);
      return;
    }
    
    if (!response.ok) {
      await logger.error('❌ Erro ao consultar backend', { status: response.status });
      await updateBadge(false);
      return;
    }
    
    const data = await response.json();
    
    // Atualiza badge baseado no status
    await updateBadge(data.isEnabled || false);
    lastStatus.isEnabled = data.isEnabled || false;
    
    // Se não há tarefa, continua
    if (!data.hasTask) {
      return; // Silencioso para não poluir logs
    }
    
    // NOVA TAREFA ENCONTRADA!
    await logger.info('========================================');
    await logger.info('📋 [24/7] NOVA TAREFA RECEBIDA!');
    await logger.info(`📦 Tipo: ${data.task?.type}`);
    await logger.info(`🔢 ID: ${data.task?.id}`);
    await logger.info('========================================');
    
    // Marca como processando
    isProcessingTask = true;
    
    // Processa a tarefa
    await processTask(data.task);
    
  } catch (error) {
    await logger.error('❌ Erro no polling', { error: error.message });
    await updateBadge(false);
  } finally {
    isProcessingTask = false;
  }
}

// ===========================================================================
// PROCESSAMENTO DE TAREFAS
// ===========================================================================
async function processTask(task) {
  await logger.info('🎯 [24/7] PROCESSANDO TAREFA');
  
  // Garante que há aba disponível
  await maintainOfficeTab();
  
  // Usa a aba mantida sempre aberta
  const tabId = keepAliveTabId || officeTabId;
  
  if (!tabId) {
    await logger.error('❌ [24/7] Nenhuma aba disponível!');
    await reportTaskResult({
      taskId: task.id,
      success: false,
      error: 'Não conseguiu abrir aba OnlineOffice'
    });
    return;
  }
  
  // Processa baseado no tipo de tarefa
  if (task.type === 'generate_batch') {
    await generateBatch(tabId, task);
  } else if (task.type === 'generate_single') {
    await generateSingle(tabId, task);
  } else if (task.type === 'renewal' || task.type === 'renew_system') {
    await logger.info('🔄 [24/7] Task de renovação detectada', { 
      type: task.type,
      taskId: task.id
    });
    await renewSystem(tabId, task);
  } else {
    await logger.warn('⚠️ Tipo de task desconhecido', { type: task.type });
  }
}

// ===========================================================================
// GERAÇÃO EM LOTE
// ===========================================================================
async function generateBatch(tabId, task) {
  const quantity = task.quantity || 10;
  let successCount = 0;
  let errorCount = 0;
  const results = [];
  
  await logger.info(`📦 [24/7] Gerando lote de ${quantity} credenciais...`);
  
  for (let i = 0; i < quantity; i++) {
    await logger.info(`🎯 Gerando credencial ${i + 1}/${quantity}...`);
    
    try {
      const response = await sendMessageToTab(tabId, {action: 'generateOne'});
      
      if (response && response.success && response.credentials) {
        successCount++;
        
        await logger.info(`✅ Sucesso! Credencial ${i + 1} gerada`, {
          username: response.credentials.username
        });
        
        results.push({
          success: true,
          username: response.credentials.username,
          password: response.credentials.password
        });
        
      } else {
        errorCount++;
        await logger.error(`❌ Erro na credencial ${i + 1}`);
        
        results.push({
          success: false,
          error: response?.error || 'Erro desconhecido'
        });
      }
      
    } catch (error) {
      errorCount++;
      await logger.error(`❌ Erro ao gerar credencial ${i + 1}`, { error: error.message });
      
      results.push({
        success: false,
        error: error.message
      });
      
      if (error.message.includes('Could not establish connection')) {
        await logger.error('🔌 Perdeu conexão com a aba. Parando lote...');
        break;
      }
    }
    
    // Aguarda entre gerações
    if (i < quantity - 1) {
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  }
  
  await logger.info(`📊 [24/7] LOTE COMPLETO: ${successCount} OK, ${errorCount} erros`);
  
  // Reporta resultados ao backend
  await reportTaskResult({
    taskId: task.id,
    type: 'generate_batch',
    results: results,
    summary: {
      successCount,
      errorCount,
      total: quantity
    }
  });
}

// ===========================================================================
// GERAÇÃO INDIVIDUAL
// ===========================================================================
async function generateSingle(tabId, task) {
  await logger.info('🎯 [24/7] Gerando credencial única...');
  
  try {
    const response = await sendMessageToTab(tabId, {action: 'generateOne'});
    
    if (response && response.success && response.credentials) {
      await logger.info('✅ [24/7] Credencial gerada com sucesso!');
      
      await reportTaskResult({
        taskId: task.id,
        type: 'generate_single',
        credentials: {
          username: response.credentials.username,
          password: response.credentials.password
        }
      });
      
    } else {
      throw new Error(response?.error || 'Erro desconhecido');
    }
    
  } catch (error) {
    await logger.error('❌ [24/7] Erro ao gerar credencial', { error: error.message });
    
    await reportTaskResult({
      taskId: task.id,
      type: 'generate_single',
      error: error.message
    });
  }
}

// ===========================================================================
// RENOVAÇÃO DE SISTEMA
// ===========================================================================
async function renewSystem(tabId, task) {
  await logger.info('🔄 [24/7] Renovando sistema IPTV...', { taskData: task });
  
  const sistemaId = task.sistemaId || 
                    task.data?.sistemaId || 
                    task.metadata?.sistemaId || 
                    null;
                     
  const originalUsername = task.data?.originalUsername || 
                          task.metadata?.originalUsername || 
                          'N/A';
  
  await logger.info('📋 [24/7] Dados da renovação', {
    sistemaId: sistemaId || 'N/A',
    usuarioAtual: originalUsername,
    taskId: task.id
  });
  
  try {
    // Parse data e metadata se forem strings
    let taskData = task.data;
    let metadata = task.metadata;
    
    if (typeof taskData === 'string') {
      try {
        taskData = JSON.parse(taskData);
      } catch (e) {
        await logger.warn('⚠️ Erro ao fazer parse do data');
      }
    }
    
    if (typeof metadata === 'string') {
      try {
        metadata = JSON.parse(metadata);
      } catch (e) {
        await logger.warn('⚠️ Erro ao fazer parse do metadata');
      }
    }
    
    // APENAS gera as credenciais
    const response = await sendMessageToTab(tabId, {action: 'generateOne'});
    
    if (response && response.success && response.credentials) {
      await logger.info('✅ [24/7] Nova credencial gerada para renovação!', {
        novoUsuario: response.credentials.username,
        sistemaId: sistemaId || 'desconhecido'
      });
      
      // Reporta sucesso ao backend
      await reportTaskResult({
        taskId: task.id,
        type: task.type || 'renewal',
        sistemaId: sistemaId,
        systemId: sistemaId,
        credentials: {
          username: response.credentials.username,
          password: response.credentials.password,
          sistemaId: sistemaId
        },
        oldCredentials: {
          username: originalUsername,
          password: taskData?.currentPassword || metadata?.currentPassword || 'unknown'
        },
        clienteId: taskData?.clienteId || metadata?.clienteId,
        metadata: {
          ...metadata,
          sistemaId: sistemaId,
          originalUsername: originalUsername,
          renewedAt: new Date().toISOString(),
          systemEdited: false
        }
      });
      
    } else {
      throw new Error(response?.error || 'Erro desconhecido ao renovar');
    }
    
  } catch (error) {
    await logger.error('❌ [24/7] Erro ao renovar sistema', { error: error.message });
    
    await reportTaskResult({
      taskId: task.id,
      type: 'renew_system',
      sistemaId: sistemaId,
      systemId: sistemaId,
      error: error.message
    });
  }
}

// ===========================================================================
// COMUNICAÇÃO COM BACKEND
// ===========================================================================
async function reportTaskResult(result) {
  if (!API_BASE) {
    API_BASE = await getApiBase();
  }
  
  await logger.info('📤 [24/7] Reportando resultado ao backend', { 
    taskId: result.taskId,
    type: result.type
  });
  
  try {
    const response = await fetch(`${API_BASE}/api/office/automation/task-complete`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Extension-Key': 'chrome-extension-secret-2024'
      },
      body: JSON.stringify(result)
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      await logger.error('❌ Erro ao reportar resultado', { 
        status: response.status,
        response: errorText 
      });
      return false;
    } else {
      const data = await response.json();
      await logger.info('✅ [24/7] Resultado reportado com sucesso');
      return true;
    }
    
  } catch (error) {
    await logger.error('❌ Erro ao reportar resultado', { error: error.message });
    return false;
  }
}

// ===========================================================================
// ATUALIZAÇÃO DE BADGE
// ===========================================================================
async function updateBadge(isEnabled) {
  const newBadge = isEnabled ? 'ON' : '';
  
  if (lastStatus.badge !== newBadge) {
    if (isEnabled) {
      chrome.action.setBadgeText({ text: '24/7' }); // Mostra "24/7" em vez de "ON"
      chrome.action.setBadgeBackgroundColor({ color: '#28a745' });
      await logger.debug('🟢 Badge: 24/7 ATIVO');
    } else {
      chrome.action.setBadgeText({ text: 'OFF' });
      chrome.action.setBadgeBackgroundColor({ color: '#dc3545' });
      await logger.debug('🔴 Badge: OFF');
    }
    
    lastStatus.badge = newBadge;
    lastStatus.isEnabled = isEnabled;
  }
}

// ===========================================================================
// LISTENER DE MENSAGENS DO POPUP
// ===========================================================================
chrome.runtime.onMessage.addListener(async (request, sender, sendResponse) => {
  await logger.debug('📨 Mensagem recebida', { type: request.type });
  
  // Mensagens de gerenciamento de logs
  if (request.type === 'getLogs') {
    const filters = request.filters || {};
    let logs = await logger.getLogs();
    
    if (filters.level) {
      logs = logs.filter(log => log.level === filters.level);
    }
    if (filters.searchText) {
      logs = await logger.searchLogs(filters.searchText);
    }
    if (filters.limit) {
      logs = logs.slice(-filters.limit);
    }
    
    sendResponse({
      success: true,
      logs: logs,
      formatted: await logger.formatLogs(logs)
    });
    return true;
  }
  
  if (request.type === 'clearLogs') {
    await logger.clearLogs();
    sendResponse({ success: true });
    return true;
  }
  
  if (request.type === 'exportLogs') {
    const exportText = await logger.exportAsText();
    sendResponse({
      success: true,
      text: exportText
    });
    return true;
  }
  
  if (request.type === 'getStatus') {
    sendResponse({
      isRunning: true, // SEMPRE está rodando em modo 24/7
      message: 'Automação 24/7 ATIVA - Funcionando continuamente em background'
    });
    return true;
  }
  
  if (request.type === 'openDashboard') {
    const dashboardUrl = API_BASE || 'http://localhost:5000';
    chrome.tabs.create({ 
      url: `${dashboardUrl}/painel-office` 
    });
    sendResponse({success: true});
    return true;
  }
  
  if (request.type === 'getCurrentServer') {
    sendResponse({ server: API_BASE });
    return true;
  }
  
  if (request.type === 'serverUpdated') {
    (async () => {
      API_BASE = request.server;
      await logger.info(`🔄 [24/7] Servidor atualizado: ${API_BASE}`);
      await checkForTasks();
    })();
    sendResponse({success: true});
    return true;
  }
  
  if (request.type === 'autoDetectServer') {
    (async () => {
      await logger.info('🔍 [24/7] Re-detectando servidor...');
      API_BASE = await getApiBase();
      await logger.info(`✅ [24/7] Servidor detectado: ${API_BASE}`);
      sendResponse({ server: API_BASE });
    })();
    return true;
  }
  
  sendResponse({
    success: false,
    message: 'Use o painel de controle web para gerenciar a automação'
  });
  return true;
});

// ===========================================================================
// LOG FINAL DE INICIALIZAÇÃO
// ===========================================================================
(async () => {
  await logger.info('✅ [24/7] Background script carregado - Modo 24/7 ATIVO!');
  await logger.info('🚀 Esta extensão agora funciona 24 horas por dia, 7 dias por semana!');
  await logger.info('📌 Uma aba do OnlineOffice será mantida sempre aberta em background.');
})();